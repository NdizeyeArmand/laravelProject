<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('header-image', getCoverImageUrl($post->cover_image)); ?>

<?php $__env->startSection('header'); ?>
<div class="post-heading">
    <h1><?php echo e($post->title); ?></h1>
    <h2 class="subheading"><?php echo e($post->subheading); ?></h2>
    <span class="meta">
        <?php echo e(__('Posted by')); ?>

        <a href="<?php echo e(route('profile.show', $post->user->username)); ?>">
            <img src="<?php echo e(getAvatarUrl($post->user->avatar)); ?>" alt="<?php echo e($post->user->name); ?>'s Avatar" style="width: 30px; height: 30px; border-radius: 50%; margin-right: 5px;">
            <?php echo e($post->user->username); ?>

        </a>
        <?php echo e($post->published_at->format('F d, Y')); ?>

    </span>
    <div class="post-tags">
        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('posts.by.tag', $tag->slug)); ?>" class="badge bg-secondary text-decoration-none link-light"><?php echo e($tag->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-post', $post)): ?>
        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-primary">Edit</a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-post', $post)): ?>
        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<article class="mb-4">
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <?php echo $post->content; ?>

            </div>
        </div>
    </div>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/posts/show.blade.php ENDPATH**/ ?>