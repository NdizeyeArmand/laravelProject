<?php $__env->startSection('full-title', 'Main'); ?>

<?php $__env->startSection('header'); ?>
<div class="site-heading">
    <h1><?php echo e(__('Explore Obsidian')); ?></h1>
    <?php if(isset($tag)): ?>
        <span class="subheading"><?php echo e(__('Posts tagged with: ') . $tag->name); ?></span>
    <?php else: ?>
        <span class="subheading"><?php echo e(__('Explore Our Latest Posts')); ?></span>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center mb-4">
        <div class="col-md-10 col-lg-8 col-xl-7">
            <div class="card tags-card">
                <div class="card-body">
                    <div class="tags-cloud">
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('posts.by.tag', $tag->slug)); ?>" class="tag-item"><?php echo e($tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('main.search')); ?>" method="GET">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <input type="text" name="q" id="q" class="form-control" placeholder="<?php echo e(__('Search posts...')); ?>" value="<?php echo e(request('q')); ?>">
                        </div>
                        <div class="col-md-4">
                            <select name="sort" class="form-select" id="sort" onchange="this.form.submit()">
                                <option value="">Sort by...</option>
                                <option value="recent" <?php echo e(request('sort') == 'recent' ? 'selected' : ''); ?>><?php echo e(__('Most Recent')); ?></option>
                                <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>><?php echo e(__('Oldest First')); ?></option>
                                <option value="title" <?php echo e(request('sort') == 'title' ? 'selected' : ''); ?>><?php echo e(__('Title (A-Z)')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary w-100">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Post preview-->
            <div class="post-preview">
                <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                <?php if($post->cover_image): ?>
                    <img src="<?php echo e(getCoverImageUrl($post->cover_image)); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid mb-3">
                <?php endif; ?>
                    <h2 class="post-title"><?php echo e($post->title); ?></h2>
                    <h3 class="post-subtitle"><?php echo e($post->subheading); ?></h3>
                </a>
                <p class="post-meta">
                    <?php echo e(__('Posted by')); ?>

                    <a href="<?php echo e(route('profile.show', $post->user->username)); ?>"><?php echo e($post->user->username); ?></a>
                    <?php echo e($post->published_at->format('F d, Y')); ?>

                </p>
                <p class="post-tags">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('posts.by.tag', $tag->slug)); ?>" class="badge bg-secondary text-decoration-none link-light"><?php echo e($tag->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-post', $post)): ?>
                    <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-primary"><?php echo e(__('Edit')); ?></a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-post', $post)): ?>
                    <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                    </form>
                <?php endif; ?>
            </div>
            <!-- Divider-->
            <hr class="my-4" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Pagination -->
            <div class="mb-4">
                <?php echo $posts->appends(request()->query())->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .card {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border: none;
    margin-bottom: 2rem;
    }
    .form-control, .form-select, .btn {
        border-radius: 20px;
    }
    .post-tags {
        margin-top: 0.5rem;
    }
    .post-tags .badge {
        margin-right: 0.3rem;
        padding: 0.3em 0.6em;
        font-size: 0.75em;
    }
    .dark-mode .badge {
        background-color: #495057 !important;
    }
    .tags-card {
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: none;
        margin-bottom: 2rem;
    }
    .dark-mode .tags-card {
        background-color: #343a40;
    }
    .tags-cloud {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 10px;
    }
    .tag-item {
        background-color: #e9ecef;
        color: #495057;
        padding: 5px 10px;
        border-radius: 20px;
        text-decoration: none;
        font-size: 0.9em;
        transition: background-color 0.3s ease;
    }
    .tag-item:hover {
        background-color: #ced4da;
        text-decoration: none;
    }
    .dark-mode .tag-item {
        background-color: #495057;
        color: #e9ecef;
    }
    .dark-mode .tag-item:hover {
        background-color: #6c757d;
    }
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }
    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }
    .dark-mode .form-control,
    .dark-mode .form-select {
        background-color: #343a40;
        color: #f8f9fa;
        border-color: #495057;
    }
    .dark-mode .form-control::placeholder {
        color: #6c757d;
    }
    .dark-mode .post-title,
    .dark-mode .post-subtitle {
        color: #f8f9fa;
    }
    .dark-mode .post-meta {
        color: #adb5bd;
    }
    .dark-mode hr {
        border-color: #495057;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/main.blade.php ENDPATH**/ ?>