<?php $__env->startSection('title', 'FAQ'); ?>

<?php $__env->startPush('head'); ?>
    <link href="<?php echo e(asset('css/faq.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
<div class="page-heading">
    <h1><?php echo e(__('Frequently Asked Questions')); ?></h1>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="mb-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-faq')): ?>
                <div class="mb-3">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <?php echo e(__('Add Category')); ?>

                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addCategoryModalLabel"><?php echo e(__('Add Category')); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('faq.categories.create')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="categoryName" class="form-label"><?php echo e(__('Category Name')); ?></label>
                                            <input type="text" class="form-control" id="categoryName" name="name" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Add Category')); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2><?php echo e($category->name); ?></h2>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-faq')): ?>
                    <div class="mb-3">
                        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#editCategoryModal<?php echo e($category->id); ?>">
                            <?php echo e(__('Edit Category')); ?>

                        </button>

                        <div class="modal fade" id="editCategoryModal<?php echo e($category->id); ?>" tabindex="-1" aria-labelledby="editCategoryModalLabel<?php echo e($category->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editCategoryModalLabel<?php echo e($category->id); ?>"><?php echo e(__('Edit Category')); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('faq.categories.edit', $category)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="mb-3">
                                                <label for="categoryName<?php echo e($category->id); ?>" class="form-label"><?php echo e(__('Category Name')); ?></label>
                                                <input type="text" class="form-control" id="categoryName<?php echo e($category->id); ?>" name="name" value="<?php echo e($category->name); ?>" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Edit Category')); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('faq.categories.destroy', $category)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><?php echo e(__('Delete Category')); ?></button>
                        </form>
                    </div>
                <?php endif; ?>
                <div class="faq-list">
                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="faq-item">
                            <h3 class="faq-question"><?php echo e(__($item->question)); ?></h3>
                            <p class="faq-answer"><?php echo __($item->answer); ?></p>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-faq')): ?>
                                <div class="mb-3">
                                    <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#editItemModal<?php echo e($item->id); ?>">
                                        <?php echo e(__('Edit Item')); ?>

                                    </button>

                                    <div class="modal fade" id="editItemModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editItemModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editItemModalLabel<?php echo e($item->id); ?>"><?php echo e(__('Edit Item')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('faq.items.edit', $item)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="mb-3">
                                                            <label for="itemQuestion<?php echo e($item->id); ?>" class="form-label"><?php echo e(__('Question')); ?></label>
                                                            <input type="text" class="form-control" id="itemQuestion<?php echo e($item->id); ?>" name="question" value="<?php echo e($item->question); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="itemAnswer<?php echo e($item->id); ?>" class="form-label"><?php echo e(__('Answer')); ?></label>
                                                            <textarea class="form-control" id="itemAnswer<?php echo e($item->id); ?>" name="answer" required><?php echo e($item->answer); ?></textarea>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Edit Item')); ?></button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <form action="<?php echo e(route('faq.items.destroy', $item)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><?php echo e(__('Delete Item')); ?></button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-faq')): ?>
                    <div class="mb-3">
                        <a href="<?php echo e(route('faq.items.create', ['category_id' => $category->id])); ?>" class="btn btn-primary"><?php echo e(__('Add Item')); ?></a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const questions = document.querySelectorAll('.faq-question');
        questions.forEach(question => {
            question.addEventListener('click', function() {
                this.classList.toggle('active');
                const answer = this.nextElementSibling;
                if (answer.style.display === 'block') {
                    answer.style.display = 'none';
                } else {
                    answer.style.display = 'block';
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/FAQ.blade.php ENDPATH**/ ?>