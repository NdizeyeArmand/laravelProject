<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keywords" content="<?php echo e(__('Obsidian Notes Markdown Think studying')); ?>">
        <meta name="author" content="Armand-Gaël Ndizeye" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>    
        <?php $__env->startSection('full-title'); ?>
            <?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Explore Obsidian')); ?>

        <?php echo $__env->yieldSection(); ?>
        </title>

        <!-- Fonts -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('img/obsidian-icon.png')); ?>" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://rsms.me/inter/inter.css">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/auth.css')); ?>" rel="stylesheet" />

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body class="<?php if(session('darkMode')): ?> dark-mode <?php endif; ?> bg-white text-gray-900 transition-colors duration-300">
        <div class="content-container">
            <div class="container-fluid h-100">
                <div class="row h-100">
                    <!-- Left side - Image -->
                    <div class="col-md-7 p-0 bg-image-container">
                        <div class="h-100 bg-image d-flex align-items-center justify-content-center" style="background-image: url('<?php echo e(asset('../img/snow-effect-with-wallpaper.gif')); ?>'); background-size: cover; background-position: center; background-repeat: no-repeat; background-color: #f0f0f0;"></div>
                    </div>

                    <!-- Vertical line -->
                    <div class="col-auto p-0">
                        <div class="vertical-line h-100"></div>
                    </div>
                    
                    <!-- Right side - Login form -->
                    <div class="col-md content-right d-flex align-items-center justify-content-center">
                        <div class="w-100 scrollable-content" style="max-width: 400px;">
                            <!-- Go Back Home button -->
                            <div class="<?php echo $__env->yieldContent('div-class'); ?>">
                            <?php echo $__env->yieldContent('return-button'); ?>
                                <div>
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary btn-sm">
                                        <i class="fas fa-home"></i> <?php echo e(__('Go Back Home')); ?>

                                    </a>
                                </div>
                            </div>

                            <?php echo $__env->yieldContent('right-content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <script src="<?php echo e(asset('js/components/auth-script.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/layouts/auth.blade.php ENDPATH**/ ?>