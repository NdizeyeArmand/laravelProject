<?php echo e($slot); ?>

<?php /**PATH /home/armand/php + tailwind/laravelProject/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>