<?php $__env->startSection('full-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Left Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('dashboard')); ?>">
                            <i class="bi bi-house-door-fill"></i>
                            <?php echo e(__('Dashboard')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                            <i class="bi bi-gear-fill"></i>
                            <?php echo e(__('Email & Password')); ?>

                        </a>
                    </li>
                    <?php if(auth()->user()->isAdmin()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.messages.index')); ?>">
                            <i class="bi bi-envelope-fill"></i>
                            <?php echo e(__('Contact messages')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bi bi-people-fill"></i>
                            <?php echo e(__('Manage Users')); ?>

                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="bi bi-box-arrow-right"></i>
                            <?php echo e(__('Sign out')); ?>

                        </a>
                    </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="dashboard-hero p-4 mb-4 rounded-3">
                <div class="py-4">
                    <h1 class="display-5 fw-bold"><?php echo e(__('Welcome to your dashboard, ') . auth()->user()->name); ?></h1>
                    <p class="col-md-8 fs-5 mb-2 text-muted"><?php echo e(__('What would you like to do today?')); ?></p>
                    <a href="<?php echo e(route('profile.show', auth()->user()->username)); ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-person me-1"></i><?php echo e(__('View my public profile')); ?>

                    </a>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="dashboard-card p-4 rounded-3 h-100">
                        <h2 class="h5 fw-bold mb-1">✍️ Writing</h2>
                        <p class="text-muted mb-3">Share your thoughts with the community</p>
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-brand"><?php echo e(__('Create new post')); ?></a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="dashboard-card p-4 rounded-3 h-100">
                        <h2 class="h5 fw-bold mb-1">📖 Reading</h2>
                        <p class="text-muted mb-3">Discover something new from the community.</p>
                        <a href="<?php echo e(route('posts.random')); ?>" class="btn btn-brand"><?php echo e(__('Read random post')); ?></a>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
<style>
    #mainNav .navbar-brand,
    #mainNav .navbar-nav > li.nav-item > a.nav-link {
        color: #212529;
    }
    #mainNav .navbar-nav > li.nav-item > a.nav-link:focus,
    #mainNav .navbar-nav > li.nav-item > a.nav-link:hover,
    #mainNav.is-fixed .navbar-brand:focus,
    #mainNav.is-fixed .navbar-brand:hover,
    #mainNav .navbar-brand:focus, #mainNav .navbar-brand:hover {
        color: #0085A1;
    }
    .dark-mode #mainNav .navbar-brand:focus, .dark-mode #mainNav .navbar-brand:hover {
        color: #0085A1 !important;
    }
    .dark-mode #mainNav .navbar-nav > li.nav-item > a.nav-link:focus, .dark-mode #mainNav .navbar-nav > li.nav-item > a.nav-link:hover {
        color: #0085A1 !important;
    }
    body.dark-mode .sidebar {
        background-color: #343a40;
    }
    body:not(.dark-mode) .sidebar {
        --bs-bg-opacity: 1;
        background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity));
    }
    .dashboard-hero {
        border: 1px solid #dee2e6;
        background-color: #f8f9fa;
    }
    .dark-mode .dashboard-hero {
        background-color: #2b3035;
        border-color: #495057;
    }
    .dark-mode .dashboard-hero h1 {
        color: #f8f9fa;
    }
    .dashboard-card {
        border: 1px solid #dee2e6;
        background-color: #fff;
    }
    .dark-mode .dashboard-card {
        background-color: #2b3035;
        border-color: #495057;
    }
    .dark-mode .dashboard-card h2 {
        color: #f8f9fa;
    }
    .dark-mode .text-muted {
        color: #adb5bd !important;
    }
    .btn-brand {
        background-color: #0085A1;
        border-color: #0085A1;
        color: #fff;
    }
    .btn-brand:hover {
        background-color: #006d84;
        border-color: #006d84;
        color: #fff;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/dashboard.blade.php ENDPATH**/ ?>