<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('header-image', asset('img/home/contact-bg.jpg')); ?>

<?php $__env->startSection('header'); ?>
<div class="page-heading">
    <h1><?php echo e(__('Contact Us')); ?></h1>
    <span class="subheading"><?php echo e(__('Have questions? We have answers.')); ?></span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="mb-4">
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <p><?php echo e(__('Want to get in touch? Fill out the form below to send us a message and we will get back to you as soon as possible!')); ?></p>
                <div class="my-5">
                    <form id="contactForm" action="<?php echo e(route('contact.submit')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input class="form-control" id="name" name="name" type="text" placeholder="<?php echo e(__('Enter your name...')); ?>" required />
                            <label for="name"><?php echo e(__('Name')); ?></label>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" id="email" name="email" type="email" placeholder="<?php echo e(__('Enter your email...')); ?>" required />
                            <label for="email"><?php echo e(__('Email address')); ?></label>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" id="phone" name="phone" type="tel" placeholder="<?php echo e(__('Enter your phone number...')); ?>" required />
                            <label for="phone"><?php echo e(__('Phone Number')); ?></label>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" id="message" name="message" placeholder="<?php echo e(__('Enter your message here...')); ?>" style="height: 12rem" required></textarea>
                            <label for="message"><?php echo e(__('Message')); ?></label>
                        </div>
                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <button class="btn btn-primary text-uppercase" id="submitButton" type="submit"><?php echo e(__('Send')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/contact.blade.php ENDPATH**/ ?>