<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/components/primary-button.blade.php ENDPATH**/ ?>