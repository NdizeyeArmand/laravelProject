<?php $__env->startSection('full-title', 'Explore Obsidian'); ?>

<?php $__env->startSection('header'); ?>
<div class="site-heading">
    <h1><?php echo e(__('Explore Obsidian')); ?></h1>
    <span class="subheading"><?php echo e(__('Discover the Best Note-Taking App')); ?></span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7">
        <h1><?php echo e(__('Welcome to the World of Personal Knowledge Management')); ?></h1>
<p><?php echo e(__('Discover')); ?> <a href="https://obsidian.md"><?php echo e(__('Obsidian')); ?></a><?php echo e(__(': The premier choice for those seeking to build and expand their knowledge base. Whether you\'re a seasoned note-taker or just starting out, Obsidian offers powerful tools to organize your thoughts and ideas.')); ?></p>

<?php if($oldestPost): ?>
    <p><?php echo e(__('New to Obsidian? Check out our')); ?> <a href="<?php echo e(route('posts.show', $oldestPost->slug)); ?>"><?php echo e(__('beginner\'s guide')); ?></a> <?php echo e(__('to get started on your journey.')); ?></p>
<?php endif; ?>

<p><?php echo e(__('We welcome all perspectives! Whether you\'re a fan or a critic, share your Obsidian experience or insights by writing a post. Your voice matters in our community.')); ?></p>

<h2><?php echo e(__('Interest piqued? Join us and explore these recent posts we\'ve lined up just for you!')); ?></h2>
            <br>
                
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Post preview-->
            <div class="post-preview">
                <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                <?php if($post->cover_image): ?>
                    <img src="<?php echo e(getCoverImageUrl($post->cover_image)); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid mb-3">
                <?php endif; ?>
                    <h2 class="post-title"><?php echo e($post->title); ?></h2>
                    <h3 class="post-subtitle"><?php echo e($post->subheading); ?></h3>
                </a>
                <p class="post-meta">
                    <?php echo e(__('Posted by')); ?>

                    <a href="<?php echo e(route('profile.show', $post->user->username)); ?>"><?php echo e($post->user->username); ?></a>
                    <?php echo e($post->published_at->format('F d, Y')); ?>

                </p>
                <p class="post-tags">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('posts.by.tag', $tag->slug)); ?>" class="badge bg-secondary text-decoration-none link-light"><?php echo e($tag->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-post', $post)): ?>
                    <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-primary">Edit</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-post', $post)): ?>
                    <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                <?php endif; ?>
            </div>
            <!-- Divider-->
            <hr class="my-4" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Pager-->
            <div class="d-flex justify-content-between mb-4">
                <div>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary"><?php echo e(__('Create New Post')); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"><?php echo e(__('Login to Create Post')); ?></a>
                    <?php endif; ?>
                </div>
                <div>
                    <a class="btn btn-primary" href="<?php echo e(route('main')); ?>"><?php echo e(__('Older Posts →')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .post-tags {
        margin-top: 0.5rem;
    }
    .post-tags .badge {
        margin-right: 0.3rem;
        padding: 0.3em 0.6em;
        font-size: 0.75em;
    }
    .dark-mode .badge {
        background-color: #495057 !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/welcome.blade.php ENDPATH**/ ?>