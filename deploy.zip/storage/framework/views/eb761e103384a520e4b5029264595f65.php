<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keywords" content="<?php echo e(__('Obsidian Notes Markdown Think studying,obsidian.md,obsidian note taking,obsidian app,obsidian notes,obsidian note,obsidian review,obsidian tutorial,obsidian workflow,obsidian zettlekasten,how to use obsidian,note taking app,https://obsidian.md/index.html,sync obsidian,obsidian onedrive sync,obsidian sync pc with mobile,obsidian sync devices,obsidian sync,obsidian sync free,obsidian sync mobile,obsidian sync tutorial,obsidian sync guide,obsidian sync android,obsidian sync onedrive')); ?>">
        <meta name="author" content="Armand-Gaël Ndizeye" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>
        <?php $__env->startSection('full-title'); ?>
            <?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Explore Obsidian')); ?>

        <?php echo $__env->yieldSection(); ?>
        </title>

        <!-- Fonts -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('img/obsidian-icon.png')); ?>" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://rsms.me/inter/inter.css">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
        <?php echo $__env->yieldPushContent('head'); ?>

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body class="<?php if(session('darkMode')): ?> dark-mode <?php endif; ?> bg-white text-gray-900 transition-colors duration-300">
        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Page Header-->
        <header class="masthead" style="background-image: url('<?php echo $__env->yieldContent('header-image', asset('img/home/home-bg.jpg')); ?>')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                    <?php echo $__env->yieldContent('header'); ?>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <?php echo $__env->yieldContent('content'); ?>

        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                            <li class="list-inline-item">
                                <a href="https://obsidian.md/" class="obsidian-icon-link">
                                    <img src="<?php echo e(asset('img/obsidian-icon.png')); ?>"
                                         alt="Obsidian"
                                         class="obsidian-icon">
                                </a>
                            </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">&copy; Explore Obsidian 2024</div>
                    </div>
                </div>
            </div>
        </footer>

    <script src="<?php echo e(asset('js/components/script.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/layouts/guest.blade.php ENDPATH**/ ?>