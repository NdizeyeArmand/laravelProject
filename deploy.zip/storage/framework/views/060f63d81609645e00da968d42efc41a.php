<?php $__env->startSection('title', $user->username); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    <div class="profile-header content-surface p-4 rounded-3 mb-4">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <img src="<?php echo e(getAvatarUrl($user->avatar)); ?>" alt="<?php echo e($user->username); ?>'s Avatar" class="img-fluid rounded-circle profile-avatar mb-3 mb-md-0">
            </div>
            <div class="col-md-9">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h1 class="mb-1"><?php echo e($user->username); ?></h1>
                <?php if(Auth::id() === $user->id): ?>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-brand btn-sm">
                        <i class="bi bi-pencil-fill me-1"></i><?php echo e(__('Edit Profile')); ?>

                    </a>
                <?php endif; ?>
            </div>
            <?php if($user->birthday): ?>
                <p class="text-muted mb-2">
                    <i class="bi bi-cake me-1"></i><?php echo e($user->birthday->format('F j, Y')); ?>

                </p>
            <?php endif; ?>
            <p class="mb-0 profile-bio"><?php echo e($user->bio ?? __('No bio available.')); ?></p>
            </div>
        </div>
    </div>


    <div class="content-surface p-4 rounded-3">
        <h2 class="h5 fw-bold mb-4">
            <i class="bi bi-file-text me-2"></i><?php echo e(__('Posts by ') . $user->username); ?>

        </h2>
        <?php if($user->posts->isEmpty()): ?>
            <p class="text-muted"><?php echo e(__('No posts yet.')); ?></p>
        <?php else: ?>
            <div class="row g-3">
                <?php $__currentLoopData = $user->posts->sortByDesc('published_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none">
                            <div class="profile-post-card p-3 rounded-3 h-100">
                                <?php if($post->cover_image): ?>
                                    <img src="<?php echo e(getCoverImageUrl($post->cover_image)); ?>"
                                        alt="<?php echo e($post->title); ?>"
                                        class="img-fluid rounded-2 mb-2"
                                        style="width: 100%; height: 140px; object-fit: cover;">
                                <?php endif; ?>
                                <h3 class="h6 fw-bold mb-1"><?php echo e($post->title); ?></h3>
                                <?php if($post->subheading): ?>
                                    <p class="text-muted small mb-1"><?php echo e($post->subheading); ?></p>
                                <?php endif; ?>
                                <p class="text-muted small mb-0">
                                    <i class="bi bi-calendar3 me-1"></i><?php echo e($post->published_at->format('M d, Y')); ?>

                                </p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
<style>
    #mainNav .navbar-brand,
    #mainNav .navbar-nav > li.nav-item > a.nav-link {
        color: #212529;
    }
    #mainNav .navbar-nav > li.nav-item > a.nav-link:focus,
    #mainNav .navbar-nav > li.nav-item > a.nav-link:hover,
    #mainNav.is-fixed .navbar-brand:focus,
    #mainNav.is-fixed .navbar-brand:hover,
    #mainNav .navbar-brand:focus, #mainNav .navbar-brand:hover {
        color: #0085A1;
    }
    .dark-mode #mainNav .navbar-brand:focus, .dark-mode #mainNav .navbar-brand:hover {
        color: #0085A1 !important;
    }
    .dark-mode #mainNav .navbar-nav > li.nav-item > a.nav-link:focus, .dark-mode #mainNav .navbar-nav > li.nav-item > a.nav-link:hover {
        color: #0085A1 !important;
    }
    .profile-avatar {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border: 3px solid #0085A1;
    }

    .profile-bio {
        line-height: 1.6;
    }

    .profile-post-card {
        border: 1px solid #dee2e6;
        background-color: #f8f9fa;
        transition: border-color 0.2s ease, transform 0.2s ease;
    }
    .profile-post-card:hover {
        border-color: #0085A1;
        transform: translateY(-2px);
    }
    .profile-post-card h3 {
        color: #212529;
    }
    .dark-mode .profile-post-card {
        background-color: #343a40;
        border-color: #495057;
    }
    .dark-mode .profile-post-card:hover {
        border-color: #0085A1;
    }
    .dark-mode .profile-post-card h3 {
        color: #f8f9fa;
    }

    .btn-brand {
        background-color: #0085A1;
        border-color: #0085A1;
        color: #fff;
    }
    .btn-brand:hover {
        background-color: #006d84;
        border-color: #006d84;
        color: #fff;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/profile/show.blade.php ENDPATH**/ ?>