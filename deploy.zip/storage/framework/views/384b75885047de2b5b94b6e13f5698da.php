<h3 class="font-weight-bold mb-3"><?php echo e(__('Update Avatar')); ?></h3>

<form method="POST" action="<?php echo e(route('user-avatar.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="avatar" class="form-label"><?php echo e(__('Choose Avatar')); ?></label>
        <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*">
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="reset_default" name="reset_default">
            <label class="form-check-label" for="reset_default">
                <?php echo e(__('Reset to default avatar')); ?>

            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-primary"><?php echo e(__('Update Avatar')); ?></button>
</form>

<div class="mt-3">
    <img src="<?php echo e(getAvatarUrl($user->avatar)); ?>" alt="<?php echo e($user->name); ?>'s Avatar" class="img-thumbnail" style="max-width: 200px;">
</div><?php /**PATH /home/armand/php + tailwind/laravelProject/resources/views/profile/partials/update-avatar-form.blade.php ENDPATH**/ ?>