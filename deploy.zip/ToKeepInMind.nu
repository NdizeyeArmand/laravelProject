# php artisan migrate:fresh --force && php artisan db:seed --force && php artisan serve --host=0.0.0.0 --port=$PORT
# php artisan migrate --force && php artisan serve --host=0.0.0.0 --port=$PORT


